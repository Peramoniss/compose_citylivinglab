jqCron
======

Cron jQuery plugin

Originaly created in july 2012.

**NOTE** : the project has move to [GitLab](https://gitlab.com/arnapou/jqcron).
If you need to open issues or merge requests, do it on GitLab.

Features
========
* multi select
* i18n
* custom binding with dom element (can be two ways sync for instance with input)
* lots of options (reset button, default value, ...)
* php class to test matching dates

Alternatives
========
* [react-js-cron](https://github.com/xrutayisire/react-js-cron/): A React cron editor with antd inspired by jqCron