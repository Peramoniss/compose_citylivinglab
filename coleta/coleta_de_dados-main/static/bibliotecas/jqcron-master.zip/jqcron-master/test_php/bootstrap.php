<?php

if (PHP_VERSION_ID < 70000) {
    date_default_timezone_set('Europe/Paris');
}

require __DIR__ . '/../vendor/autoload.php';
